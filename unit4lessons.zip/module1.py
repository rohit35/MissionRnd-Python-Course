__author__ = 'Kalyan'

# this is a sample module for the understanding_modules assignment.

def greet(name):
    return "module1 says hi to " + name

def _private_func():
    pass

